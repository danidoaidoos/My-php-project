<?php

    include "logic.php";
    session_start();
   
   if($_SERVER["REQUEST_METHOD"] == "POST") {
      // username and password sent from form 
      
      $myusername = mysqli_real_escape_string($db,$_POST['username']);
      $mypassword = mysqli_real_escape_string($db,$_POST['password']); 
      
      $sql = "SELECT id FROM admin WHERE username = '$myusername' and passcode = '$mypassword'";
      $result = mysqli_query($db,$sql);
      $row = mysqli_fetch_array($result,MYSQLI_ASSOC);
      $active = $row['active'];
      
      $count = mysqli_num_rows($result);
      
      // If result matched $myusername and $mypassword, table row must be 1 row
		
      if($count == 1) {
        //  session_register("myusername");
         $_SESSION['login_user'] = $myusername;
         
         header("location: welcome.php");
      }else {
         $error = "Your Login Name or Password is invalid";
      }
   }

   // verify all the required form data was entered
if ($username != "" && $passwd != "" && $passwd_again != ""){
    // make sure the two passwords match
    if ($passwd === $passwd_again){
        // make sure the password meets the min strength requirements
        if ( strlen($passwd) >= 5 && strpbrk($passwd, "!#$.,:;()") != false ){
            // next code block
        }
        else
            $error_msg = 'Your password is not strong enough. Please use another.';
    }
    else
        $error_msg = 'Your passwords did not match.';
}
else
    $error_msg = 'Please fill out all required fields.';


// insert the user into the database
mysqli_query($conn, "INSERT INTO users VALUES (
    '{$id}', '{$username}', '{$email}', '{$passwd}', '{$date_created}', '{$last_login}', '{$status}'
)");

// verify the user's account was created
$query = mysqli_query($conn, "SELECT * FROM users WHERE username='{$username}'");
if (mysqli_num_rows($query) == 1){
    
    /* IF WE ARE HERE THEN THE ACCOUNT WAS CREATED! YAY! */
    /* WE WILL SEND EMAIL ACTIVATION CODE HERE LATER */

    $success = true;
}
else
    $error_msg = 'An error occurred and your account was not created.';

?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- Bootstrap CSS -->
    <!-- <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css"
        integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous"> -->

    <!-- tailwind -->
    <link rel="stylesheet" href="../styles.css">

    <title>ARCADEBLOGS</title>
</head>

<body>

    <!--  -->

    <div class="h-10 w-screen bg-zinc-900  flex justify-around items-center text-white font-ArchitectDaughter">
        <div>
            <div class="flex space-x-2 capitalize">

                <div class="cursor-pointer"><a href="index.php">Arcadeblog</a></div>
                <div class=" cursor-pointer"><a href="">membership</a></div>
                <div class="text-lime-300 font-shizuru font-extrabold cursor-pointer">

                    <a href="create.php">write</a>


                </div>
            </div>
        </div>
        <div class="flex space-x-2 capitalize">



            <div>
                <a class="" href="./login.php">login</a>
            </div>



            <div>
                <a class="" href="./register.php">register</a>
            </div>




        </div>
    </div>
    <!-- eend -->


    <div
        class=' w-screen h-screen  bg-[url("https://cdn.pixabay.com/photo/2021/09/15/13/28/art-6626881_1280.png")] bg-cover flex justify-center items-center '>
        <div
            class=' w-96 bg-slate-700 bg-opacity-50 rounded-xl py-10 px-4 border-t-2 border-r-4 border-b-2 border-opacity-30 border-gray-700'>
            <div class='font-Yanone_Kaffeesatz  text-4xl text-rose-500 uppercase text-center w-full'>
                Register your account
            </div>
            <form method="POST" action="{{ route('register') }}">

                <div class="flex flex-col text-white">
                    <label for="name" class="font-ArchitectDaughter  font-bold  text-xl">Name</label>

                    <div class="flex flex-col">
                        <input id="name" type="text" class="form-control @error('name') is-invalid @enderror"
                            name="name" value="{{ old('name') }}" required autocomplete="name" autofocus>

                        <!-- @error('name')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                @enderror -->
                    </div>
                </div>
                <div class="flex flex-col text-white">
                    <label for="email" class="font-ArchitectDaughter font-bold  text-xl">Email Address</label>

                    <div class="">
                        <input id="email" type="email" class="w-full form-control @error('email') is-invalid @enderror"
                            name="email" value="{{ old('email') }}" required autocomplete="email">

                        <!-- @error('email')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                @enderror -->
                    </div>
                </div>

                <div class="flex flex-col text-white">
                    <label for="password" class="font-ArchitectDaughter font-bold  text-xl">Password</label>

                    <div class="">
                        <input id="password" type="password"
                            class="w-full form-control @error('password') is-invalid @enderror" name="password" required
                            autocomplete="new-password">

                        <!-- @error('password')
                                    <span class="" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                @enderror -->
                    </div>
                </div>
                <div class="flex flex-col text-white">
                    <label for="password-confirm" class="font-ArchitectDaughter font-bold  text-xl">Confirm
                        Password</label>

                    <div class="">
                        <input id="password-confirm" type="password" class="w-full form-control"
                            name="password_confirmation" required autocomplete="new-password">
                    </div>
                </div>
                <div class='flex justify-center py-2'>
                    <button type='submit' class='bg-black text-white px-6 py-1 rounded-xl'>
                        Register
                    </button>
                </div>
            </form>
        </div>
    </div>

    <!-- footer -->
    <div class='w-screen flex justify-center items-center py-8 mb-20'>
        <div class='grid grid-cols-5 gap-x-10 gap-y-20 '>
            <div class='space-y-3 font-extralight'>
                <div class='text-center font-bold '>social</div>
                <div class='flex space-x-2'>
                    <div>
                        <img src='https://img.icons8.com/color/144/000000/facebook.png' alt='' class='h-6 w-6' />
                    </div>

                    <div>facebook</div>
                </div>

                <div class='flex space-x-2 '>
                    <div>
                        <img src='https://img.icons8.com/color/144/000000/instagram-new--v1.png' alt=''
                            class='h-6 w-6' />
                    </div>

                    <div>instagram</div>
                </div>
                <div class='flex space-x-2 '>
                    <div>
                        <img src='https://img.icons8.com/color/240/000000/youtube-play.png' alt='' class='h-6 w-6' />
                    </div>

                    <div>youtube</div>
                </div>
                <div class='flex space-x-2 '>
                    <div>
                        <img src='https://img.icons8.com/fluency/144/000000/twitter.png' alt='' class='h-6 w-6' />
                    </div>

                    <div>twitter</div>
                </div>
            </div>
            <div class='space-y-3 font-extralight'>
                <h1 class=' font-bold'>about</h1>
                <h1>style guide</h1>
                <h1>contact</h1>
                <h1>get theme</h1>
                <h1>you me</h1>
            </div>
            <div class='space-y-3 font-extralight'>
                <h1 class=' font-bold'>Features</h1>
                <h1>feature</h1>
                <h1>Author</h1>
                <h1>tag</h1>
                <h1>got</h1>
            </div>
            <div class='space-y-3 font-extralight'>
                <h1 class=' font-bold'>support</h1>
                <h1>serpia version</h1>
                <h1>dark vision</h1>
                <h1>membership</h1>
                <h1>you me</h1>
            </div>
            <div class='space-y-3 font-extralight'>
                <h1 class=' font-bold'>about</h1>
                <h1>style guide</h1>
                <h1>contact</h1>
                <h1>get theme</h1>
                <h1>you me</h1>
            </div>
        </div>
    </div>
    <!-- footer end -->




    <!-- Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"
        integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous">
    </script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"
        integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous">
    </script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"
        integrity="sha384-B4gt1jrGC7Jh4AgTPSdUtOBvfO8shuf57BaghqFfPlYxofvL8/KUEfYiJOMMV+rV" crossorigin="anonymous">
    </script>

</body>

</html>