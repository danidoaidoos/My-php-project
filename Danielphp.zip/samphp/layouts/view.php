<?php

    include "logic.php";

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- Bootstrap CSS -->
    <!-- <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css"
        integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous"> -->

    <!-- tailwind -->
    <link rel="stylesheet" href="../styles.css">

    <title>ARCADEBLOGS</title>
</head>

<body>
    <!--  -->

    <div class="h-10 w-screen bg-zinc-900  flex justify-around items-center  font-ArchitectDaughter">
        <div>
            <div class="flex space-x-2 capitalize">

                <div class="cursor-pointer"><a href="index.php">Arcadeblog</a></div>
                <div class=" cursor-pointer"><a href="">membership</a></div>
                <div class="text-lime-300 font-shizuru font-extrabold cursor-pointer">

                    <a href="create.php">write</a>


                </div>
            </div>
        </div>
        <div class="flex space-x-2 capitalize">



            <div>
                <a class="" href="./login.php">login</a>
            </div>



            <div>
                <a class="" href="./register.php">register</a>
            </div>




        </div>
    </div>
    <!-- eend -->



    <!-- single -->


    <?php foreach($query as $q){?>
    <div class='flex justify-center items-center w-screen mt-16'>
        <div>
            <div class='w-big h-bigxx bg-zinc-800 px-8 space-y-3 py-5'>
                <div class='w-full flex justify-center text-6xl font-Yanone_Kaffeesatz  mb-4 uppercase'>
                    <h2><?php echo $q['title'];?></h2>
                </div>
                <div class='w-full'>
                    <div class='w-full h-small2 bg-slate-600  overflow-hidden   '>
                        <img src='https://cdn.pixabay.com/photo/2018/01/11/21/27/desk-3076954_1280.jpg' alt=''
                            class='object-cover h-full w-full' />
                    </div>
                </div>
                <div class='space-y-4'>
                    <div class="flex justify-between">
                        <div class="flex">
                            <div>Author:</div>
                            <div>name</div>
                        </div>
                        <div>
                            Created on
                        </div>

                    </div>

                    <div>

                        <div class='w-full flex justify-end '>
                            <div class='flex px-2 space-x-2'>
                                <a class='bg-lime-700 px-3 py-1 rounded-md' href="edit.php?id=<?php echo $q['id']?>">
                                    update
                                </a>
                                <div>
                                    <form method="post">
                                        <input type="text" hidden value='<?php echo $q['id']?>' name="id">
                                        <button class='bg-red-700 px-3 py-1 rounded-md' type="submit" name="delete">
                                            delete
                                        </button>
                                    </form>
                                </div>
                                <div>
                                </div>
                            </div>

                        </div>

                        <div class="font-body text-xl mt-5">
                            <p>
                                <?php echo $q['content'];?>
                            </p>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php } ?>
    <!-- single end -->







    <!-- footer -->
    <div class='w-screen flex justify-center items-center py-8 mb-20'>
        <div class='grid grid-cols-5 gap-x-10 gap-y-20 '>
            <div class='space-y-3 font-extralight'>
                <div class='text-center font-bold '>social</div>
                <div class='flex space-x-2'>
                    <div>
                        <img src='https://img.icons8.com/color/144/000000/facebook.png' alt='' class='h-6 w-6' />
                    </div>

                    <div>facebook</div>
                </div>

                <div class='flex space-x-2 '>
                    <div>
                        <img src='https://img.icons8.com/color/144/000000/instagram-new--v1.png' alt=''
                            class='h-6 w-6' />
                    </div>

                    <div>instagram</div>
                </div>
                <div class='flex space-x-2 '>
                    <div>
                        <img src='https://img.icons8.com/color/240/000000/youtube-play.png' alt='' class='h-6 w-6' />
                    </div>

                    <div>youtube</div>
                </div>
                <div class='flex space-x-2 '>
                    <div>
                        <img src='https://img.icons8.com/fluency/144/000000/twitter.png' alt='' class='h-6 w-6' />
                    </div>

                    <div>twitter</div>
                </div>
            </div>
            <div class='space-y-3 font-extralight'>
                <h1 class=' font-bold'>about</h1>
                <h1>style guide</h1>
                <h1>contact</h1>
                <h1>get theme</h1>
                <h1>you me</h1>
            </div>
            <div class='space-y-3 font-extralight'>
                <h1 class=' font-bold'>Features</h1>
                <h1>feature</h1>
                <h1>Author</h1>
                <h1>tag</h1>
                <h1>got</h1>
            </div>
            <div class='space-y-3 font-extralight'>
                <h1 class=' font-bold'>support</h1>
                <h1>serpia version</h1>
                <h1>dark vision</h1>
                <h1>membership</h1>
                <h1>you me</h1>
            </div>
            <div class='space-y-3 font-extralight'>
                <h1 class=' font-bold'>about</h1>
                <h1>style guide</h1>
                <h1>contact</h1>
                <h1>get theme</h1>
                <h1>you me</h1>
            </div>
        </div>
    </div>
    <!-- footer end -->

    <!-- Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"
        integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous">
    </script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"
        integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous">
    </script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"
        integrity="sha384-B4gt1jrGC7Jh4AgTPSdUtOBvfO8shuf57BaghqFfPlYxofvL8/KUEfYiJOMMV+rV" crossorigin="anonymous">
    </script>

</body>

</html>