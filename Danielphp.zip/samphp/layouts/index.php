<?php

    include "logic.php";

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- Bootstrap CSS -->
    <!-- <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css"
        integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous"> -->

    <!-- tailwind -->
    <link rel="stylesheet" href="../styles.css">
    <script src="https://cdn.tailwindcss.com"></script>

    <title>ARCADEBLOGS</title>
</head>

<body>
    <!-- nav -->
    <div class="h-10 w-screen bg-zinc-900  flex justify-around items-center text-white font-ArchitectDaughter">
        <div>
            <div class="flex space-x-2 capitalize">

                <div class="cursor-pointer"><a href="index.php">Arcadeblog</a></div>
                <div class=" cursor-pointer"><a href="">membership</a></div>
                <div class="text-lime-300 font-shizuru font-extrabold cursor-pointer">

                    <a href="create.php">write</a>


                </div>
            </div>
        </div>
        <div class="flex space-x-2 capitalize">



            <div>
                <a class="" href="./login.php">login</a>
            </div>



            <div>
                <a class="" href="./register.php">register</a>
            </div>




        </div>
    </div>

    <!-- nav end -->

    <!-- show -->
    <div
        class="h-small1  w-screen bg-[url('https://cdn.pixabay.com/photo/2018/01/11/21/27/desk-3076954_1280.jpg')] bg-cover">
        <div class='w-full flex flex-col justify-center items-center h-[calc(100%-10rem)] space-y-16 '>
            <p class='text-7xl font-display text-rose-500'>
                Thoughts, stories and
                <br />
                ideas by the arcade team
            </p>
            <div class='w-3/4  relative z-10'>
                <h3 class='text-4xl font-bold bg-opacity-10 text-purple-600 backdrop-blur-sm font-redressed  '>
                    Arcade is a mininal theme for ghost. a beautiful way to share your
                    storieswith your glowing audience
                </h3>
            </div>
            <div class='w-2/4   flex justify-start'>
                <button class='font-bold rounded-lg bg-rose-400 text-white px-3 py-3 '>
                    Become a subsciber
                </button>
            </div>
        </div>
    </div>
    <!-- end show -->


    <!-- /* featured posts */  -->
    <div class='flex justify-center w-screen py-10 mt-32 bg-gray-100'>
        <div class='grid  grid-flow-col  space-x-8 '>
            <div
                class='w-72 h-96 bg-slate-600 rounded-6xl overflow-hidden relative transition-all duration-200 hover:-translate-y-2 '>
                <img src='https://cdn.pixabay.com/photo/2021/02/24/09/51/magical-6046020_1280.jpg' alt=''
                    class='object-cover h-full w-full' />
                <div
                    class='z-10 text-white absolute left-0 right-0 bottom-0 top-0 flex flex-col  py-5 hover:bg-gray-800 hover:bg-opacity-10 transition-opacity duration-300'>
                    <div class="bg-opacity-20 backdrop-blur-sm mt-60 ">
                        <div class="w-full text-center font-extrabold text-2xl font-ArchitectDaughter uppercase">the
                            smell of natural air</div>
                        <div class="text-zinc-50 font-light ml-5">For many people, the smell of clean air is the scent
                            of the air outdoors after a thunderstorm. And unfortunately, that smell is often ozone.
                        </div>
                    </div>

                </div>
            </div>
            <div
                class='w-72 h-96 bg-slate-600 rounded-6xl overflow-hidden relative transition-all duration-200 hover:-translate-y-2 '>
                <img src='https://cdn.pixabay.com/photo/2018/07/21/03/55/woman-3551832_1280.jpg' alt=''
                    class='object-cover h-full w-full' />
                <div
                    class='z-10 text-white absolute left-0 right-0 bottom-0 top-0 flex flex-col   py-5 hover:bg-gray-800 hover:bg-opacity-10 transition-opacity duration-300'>
                    <div class="bg-opacity-20 backdrop-blur-sm mt-60 ">
                        <div class="w-full text-center font-extrabold text-2xl font-ArchitectDaughter uppercase">Horses
                            and love</div>
                        <div class="text-zinc-50 font-light ml-5">Although horses are such well-known animals, the
                            following facts may surprise you about these magnificent creatures.</div>
                    </div>
                </div>
            </div>
            <div
                class='w-72 h-96 bg-slate-600 rounded-6xl overflow-hidden relative transition-all duration-200 hover:-translate-y-2 '>
                <img src='https://cdn.pixabay.com/photo/2017/06/26/02/47/man-2442565_1280.jpg' alt=''
                    class='object-cover h-full w-full' />
                <div
                    class='z-10 text-white absolute left-0 right-0 bottom-0 top-0 flex flex-col  py-5 hover:bg-gray-800 hover:bg-opacity-10 transition-opacity duration-300'>
                    <div class="bg-opacity-20 backdrop-blur-sm  mt-60">
                        <div class="w-full text-center font-extrabold text-2xl font-ArchitectDaughter uppercase">life's
                            Great</div>
                        <div class="text-zinc-50 font-light ml-5">Life is not what you get out of it . . . it’s what you
                            put back in. Yet our current means for summarizing life’s work, from resumes to salaries,
                            are devoid of what</div>
                    </div>
                </div>
            </div>

            <div
                class='w-72 h-96 bg-slate-600 rounded-6xl overflow-hidden relative transition-all duration-200 hover:-translate-y-2 '>
                <img src='https://cdn.pixabay.com/photo/2017/12/28/16/18/bicycle-3045580_1280.jpg' alt=''
                    class='object-cover h-full w-full' />
                <div
                    class='z-10 text-white absolute left-0 right-0 bottom-0 top-0 flex flex-col  justify-end py-5 hover:bg-gray-800 hover:bg-opacity-10 transition-opacity duration-300'>
                    <div class="bg-opacity-20 backdrop-blur-sm">
                        <div class="w-full text-center font-extrabold text-2xl font-ArchitectDaughter uppercase">life's
                            Great</div>
                        <div class="text-zinc-50 font-light ml-5">Unpleasant odors can be a warning sign of potential
                            risks to human health. Sometimes people can smell certain chemicals in the air before they
                            are at ...</div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- featurd end -->

    <div class="container mt-5">

        <!-- Display any info -->
        <?php if(isset($_REQUEST['info'])){ ?>
        <?php if($_REQUEST['info'] == "added"){?>
        <div class="py-2 bg-green-200 px-2">
            Post has been added successfully
        </div>
        <?php }?>
        <?php } ?>



        <!-- Display posts from database -->

        <div class='flex  items-center flex-col w-screen py-10 mt-24'>
            <div class='grid   grid-cols-3  gap-x-5 gap-y-3'>

                <?php foreach($query as $q){ ?>


                <div class='w-72 h-80 bg-slate-600 rounded-6xl overflow-hidden relative  '>
                    <img src='https://cdn.pixabay.com/photo/2018/01/11/21/27/desk-3076954_1280.jpg' alt=''
                        class='object-cover h-full w-full' />
                    <a href="view.php?id=<?php echo $q['id']?>">
                        <div
                            class='z-10 text-black absolute left-0 right-0 bottom-0 top-0 flex flex-col  justify-end py-5 hover:bg-gray-800 hover:bg-opacity-20 transition-all duration-300 '>
                            <div class="bg-opacity-20 backdrop-blur-sm">
                                <div
                                    class="w-full text-center font-extrabold text-2xl font-ArchitectDaughter uppercase ">
                                    <?php echo $q['title'];?></div>


                                <div class="h-10 overflow-hidden ml-5 font-bold">
                                    <?php echo substr($q['content'], 0, 50);?>...
                                </div>
                            </div>
                        </div>
                    </a>
                </div>

                <?php }?>
            </div>
        </div>

    </div>


    <!-- footer -->
    <div class='w-screen flex justify-center items-center py-8 mb-20'>
        <div class='grid grid-cols-5 gap-x-10 gap-y-20 '>
            <div class='space-y-3 font-extralight'>
                <div class='text-center font-bold '>social</div>
                <div class='flex space-x-2'>
                    <div>
                        <img src='https://img.icons8.com/color/144/000000/facebook.png' alt='' class='h-6 w-6' />
                    </div>

                    <div>facebook</div>
                </div>

                <div class='flex space-x-2 '>
                    <div>
                        <img src='https://img.icons8.com/color/144/000000/instagram-new--v1.png' alt=''
                            class='h-6 w-6' />
                    </div>

                    <div>instagram</div>
                </div>
                <div class='flex space-x-2 '>
                    <div>
                        <img src='https://img.icons8.com/color/240/000000/youtube-play.png' alt='' class='h-6 w-6' />
                    </div>

                    <div>youtube</div>
                </div>
                <div class='flex space-x-2 '>
                    <div>
                        <img src='https://img.icons8.com/fluency/144/000000/twitter.png' alt='' class='h-6 w-6' />
                    </div>

                    <div>twitter</div>
                </div>
            </div>
            <div class='space-y-3 font-extralight'>
                <h1 class=' font-bold'>about</h1>
                <h1>style guide</h1>
                <h1>contact</h1>
                <h1>get theme</h1>
                <h1>you me</h1>
            </div>
            <div class='space-y-3 font-extralight'>
                <h1 class=' font-bold'>Features</h1>
                <h1>feature</h1>
                <h1>Author</h1>
                <h1>tag</h1>
                <h1>got</h1>
            </div>
            <div class='space-y-3 font-extralight'>
                <h1 class=' font-bold'>support</h1>
                <h1>serpia version</h1>
                <h1>dark vision</h1>
                <h1>membership</h1>
                <h1>you me</h1>
            </div>
            <div class='space-y-3 font-extralight'>
                <h1 class=' font-bold'>about</h1>
                <h1>style guide</h1>
                <h1>contact</h1>
                <h1>get theme</h1>
                <h1>you me</h1>
            </div>
        </div>
    </div>
    <!-- footer end -->

    <!-- Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"
        integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous">
    </script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"
        integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous">
    </script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"
        integrity="sha384-B4gt1jrGC7Jh4AgTPSdUtOBvfO8shuf57BaghqFfPlYxofvL8/KUEfYiJOMMV+rV" crossorigin="anonymous">
    </script>

</body>

</html>