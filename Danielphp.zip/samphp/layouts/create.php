<?php

    include "logic.php";

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- Bootstrap CSS -->
    <!-- <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css"
        integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous"> -->

    <!-- tailwining -->
    <link rel="stylesheet" href="../styles.css">
    <script src="https://cdn.tailwindcss.com"></script>
    <title>ARCADEBLOGS</title>
</head>

<body>
    <!--  -->

    <div class="h-10 w-screen bg-zinc-900  flex justify-around items-center text-white font-ArchitectDaughter">
        <div>
            <div class="flex space-x-2 capitalize">

                <div class="cursor-pointer"><a href="index.php">Arcadeblog</a></div>
                <div class=" cursor-pointer"><a href="">membership</a></div>
                <div class="text-lime-300 font-shizuru font-extrabold cursor-pointer">

                    <a href="create.php">write</a>


                </div>
            </div>
        </div>
        <div class="flex space-x-2 capitalize">



            <div>
                <a class="" href="./login.php">login</a>
            </div>



            <div>
                <a class="" href="./register.php">register</a>
            </div>



        </div>
    </div>
    <!-- eend -->


    <!--post form  -->

    <!-- <div class="container mt-5">
        <form method="POST">
            <input type="text" placeholder="Blog Title" class="form-control my-3 bg-dark text-white text-center"
                name="title">
            <textarea name="content" class="form-control my-3 bg-dark text-white" cols="30" rows="10"></textarea>
            <button class="btn btn-dark" name="new_post">Add Post</button>
        </form>
    </div> -->


    <div
        class='w-screen h-screen flex justify-center items-center bg-[url("https://cdn.pixabay.com/photo/2020/03/25/13/03/house-4967221_1280.jpg")]'>
        <div class='w-small1 bg-gray-700  px-6 py-4'>


            <form class=' space-y-6' method="post">


                <div class='flex flex-col'>
                    <label for='title' class='font-ArchitectDaughter  font-bold  text-xl text-lime-500'>
                        Title:
                    </label>

                    <input type='text' id='title' placeholder='TITLE' name="title"
                        class='bg-opacity-20 bg-yellow-200' />
                </div>
                <!-- <div class='flex flex-col w-40 '>
						<label
							for='title'
							class='font-ArchitectDaughter  font-bold  text-xl text-amber-500'
						>
							file
						</label>

						<input type='file' id='title' class='' name="image" />
					</div> -->
                <div class=' '>
                    <div class='font-ArchitectDaughter  font-bold  text-xl text-rose-300'>
                        description
                    </div>
                    <div class='overflow-scroll '>

                        <textarea class="w-full h-96" name="content"></textarea>
                    </div>
                </div>
                <div>
                    <button class='bg-green-800 text-white rounded-lg px-3 font-ArchitectDaughter py-2 font-extrabold '
                        name="new_post">
                        publish
                    </button>
                </div>
            </form>
        </div>
    </div>

    <!-- postform end -->

    <!-- footer -->
    <div class='w-screen flex justify-center items-center py-8 mb-20'>
        <div class='grid grid-cols-5 gap-x-10 gap-y-20 '>
            <div class='space-y-3 font-extralight'>
                <div class='text-center font-bold '>social</div>
                <div class='flex space-x-2'>
                    <div>
                        <img src='https://img.icons8.com/color/144/000000/facebook.png' alt='' class='h-6 w-6' />
                    </div>

                    <div>facebook</div>
                </div>

                <div class='flex space-x-2 '>
                    <div>
                        <img src='https://img.icons8.com/color/144/000000/instagram-new--v1.png' alt=''
                            class='h-6 w-6' />
                    </div>

                    <div>instagram</div>
                </div>
                <div class='flex space-x-2 '>
                    <div>
                        <img src='https://img.icons8.com/color/240/000000/youtube-play.png' alt='' class='h-6 w-6' />
                    </div>

                    <div>youtube</div>
                </div>
                <div class='flex space-x-2 '>
                    <div>
                        <img src='https://img.icons8.com/fluency/144/000000/twitter.png' alt='' class='h-6 w-6' />
                    </div>

                    <div>twitter</div>
                </div>
            </div>
            <div class='space-y-3 font-extralight'>
                <h1 class=' font-bold'>about</h1>
                <h1>style guide</h1>
                <h1>contact</h1>
                <h1>get theme</h1>
                <h1>you me</h1>
            </div>
            <div class='space-y-3 font-extralight'>
                <h1 class=' font-bold'>Features</h1>
                <h1>feature</h1>
                <h1>Author</h1>
                <h1>tag</h1>
                <h1>got</h1>
            </div>
            <div class='space-y-3 font-extralight'>
                <h1 class=' font-bold'>support</h1>
                <h1>serpia version</h1>
                <h1>dark vision</h1>
                <h1>membership</h1>
                <h1>you me</h1>
            </div>
            <div class='space-y-3 font-extralight'>
                <h1 class=' font-bold'>about</h1>
                <h1>style guide</h1>
                <h1>contact</h1>
                <h1>get theme</h1>
                <h1>you me</h1>
            </div>
        </div>
    </div>
    <!-- footer end -->

    <!-- Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"
        integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous">
    </script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"
        integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous">
    </script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"
        integrity="sha384-B4gt1jrGC7Jh4AgTPSdUtOBvfO8shuf57BaghqFfPlYxofvL8/KUEfYiJOMMV+rV" crossorigin="anonymous">
    </script>

</body>

</html>