<?php

    include "logic.php";
    session_start();
   
   if($_SERVER["REQUEST_METHOD"] == "POST") {
      // username and password sent from form 
      
      $myusername = mysqli_real_escape_string($db,$_POST['username']);
      $mypassword = mysqli_real_escape_string($db,$_POST['password']); 
      
      $sql = "SELECT id FROM admin WHERE username = '$myusername' and passcode = '$mypassword'";
      $result = mysqli_query($db,$sql);
      $row = mysqli_fetch_array($result,MYSQLI_ASSOC);
      $active = $row['active'];
      
      $count = mysqli_num_rows($result);
      
      // If result matched $myusername and $mypassword, table row must be 1 row
		
      if($count == 1) {
        //  session_register("myusername");
         $_SESSION['login_user'] = $myusername;
         
         header("location: welcome.php");
      }else {
         $error = "Your Login Name or Password is invalid";
      }
   }

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- Bootstrap CSS -->
    <!-- <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css"
        integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous"> -->

    <!-- tailwind -->
    <link rel="stylesheet" href="../styles.css">

    <title>ARCADEBLOGS</title>
</head>

<body>
    <!--  -->

    <div class="h-10 w-screen bg-gray-700  flex justify-around items-center text-white font-ArchitectDaughter">
        <div>
            <div class="flex space-x-2 capitalize">

                <div class="cursor-pointer"><a href="index.php">Arcadeblog</a></div>
                <div class=" cursor-pointer"><a href="">membership</a></div>
                <div class="text-lime-300 font-shizuru font-extrabold cursor-pointer">

                    <a href="create.php">write</a>


                </div>
            </div>
        </div>
        <div class="flex space-x-2 capitalize">



            <div>
                <a class="" href="./login.php">login</a>
            </div>



            <div>
                <a class="" href="./register.php">register</a>
            </div>



        </div>
    </div>
    <!-- eend -->
    <div
        class=' w-screen h-screen  bg-[url("https://cdn.pixabay.com/photo/2021/04/26/01/39/trees-6207925_1280.jpg")] bg-cover flex justify-center items-center '>
        <div
            class='h-small2 w-96 bg-white bg-opacity-50 rounded-xl py-10 px-4 border-t-2 border-r-4 border-b-2 border-opacity-30 border-gray-700'>
            <div class='font-Yanone_Kaffeesatz  text-4xl text-rose-500 uppercase text-center w-full'>
                Login into your account
            </div>
            <form method="POST" action="{{ route('login') }}" class=" w-full  space-y-2">

                <div class='flex flex-col'>
                    <label for="email" class="font-ArchitectDaughter font-bold  text-xl">Email Address</label>

                    <div class="w-full">
                        <input id="email" type="email"
                            class="bg-opacity-20 bg-yellow-200 w-full form-control @error('email') is-invalid @enderror"
                            name="email" required autocomplete="email" autofocus>
                        <!-- 
                                @error('email')
                                    <span class="" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                @enderror -->
                    </div>
                </div>
                <div class='flex flex-col'>
                    <label for="password" class="font-ArchitectDaughter font-bold  text-xl">Password</label>

                    <div class="">
                        <input id="password" type="password"
                            class="bg-opacity-20 bg-yellow-200 w-full form-control @error('password') is-invalid @enderror"
                            name="password" required autocomplete="current-password">

                        <!-- @error('password')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                @enderror -->
                    </div>
                </div>
                <div class="flex flex-col">
                    <div class="">
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" name="remember" id="remember">

                            <label class="form-check-label" for="remember">
                                Remember Me
                            </label>
                        </div>
                    </div>

                </div>
                <div class='flex flex-col'>
                    <div class="w-full flex justify-center text-white ">
                        <button type="submit" class="bg-black py-1 px-3 rounded-lg" name="login">
                            Login
                        </button>
                    </div>
                    <!-- 
                                @if (Route::has('password.request'))
                                    <a class=" mt-3" href="{{ route('password.request') }}">
                                        {{ __('Forgot Your Password?') }}
                                    </a>
                                @endif -->
                </div>
            </form>
        </div>
    </div>
    <!-- footer -->
    <div class='w-screen flex justify-center items-center py-8 mb-20'>
        <div class='grid grid-cols-5 gap-x-10 gap-y-20 '>
            <div class='space-y-3 font-extralight'>
                <div class='text-center font-bold '>social</div>
                <div class='flex space-x-2'>
                    <div>
                        <img src='https://img.icons8.com/color/144/000000/facebook.png' alt='' class='h-6 w-6' />
                    </div>

                    <div>facebook</div>
                </div>

                <div class='flex space-x-2 '>
                    <div>
                        <img src='https://img.icons8.com/color/144/000000/instagram-new--v1.png' alt=''
                            class='h-6 w-6' />
                    </div>

                    <div>instagram</div>
                </div>
                <div class='flex space-x-2 '>
                    <div>
                        <img src='https://img.icons8.com/color/240/000000/youtube-play.png' alt='' class='h-6 w-6' />
                    </div>

                    <div>youtube</div>
                </div>
                <div class='flex space-x-2 '>
                    <div>
                        <img src='https://img.icons8.com/fluency/144/000000/twitter.png' alt='' class='h-6 w-6' />
                    </div>

                    <div>twitter</div>
                </div>
            </div>
            <div class='space-y-3 font-extralight'>
                <h1 class=' font-bold'>about</h1>
                <h1>style guide</h1>
                <h1>contact</h1>
                <h1>get theme</h1>
                <h1>you me</h1>
            </div>
            <div class='space-y-3 font-extralight'>
                <h1 class=' font-bold'>Features</h1>
                <h1>feature</h1>
                <h1>Author</h1>
                <h1>tag</h1>
                <h1>got</h1>
            </div>
            <div class='space-y-3 font-extralight'>
                <h1 class=' font-bold'>support</h1>
                <h1>serpia version</h1>
                <h1>dark vision</h1>
                <h1>membership</h1>
                <h1>you me</h1>
            </div>
            <div class='space-y-3 font-extralight'>
                <h1 class=' font-bold'>about</h1>
                <h1>style guide</h1>
                <h1>contact</h1>
                <h1>get theme</h1>
                <h1>you me</h1>
            </div>
        </div>
    </div>
    <!-- footer end -->

    <!-- Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"
        integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous">
    </script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"
        integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous">
    </script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"
        integrity="sha384-B4gt1jrGC7Jh4AgTPSdUtOBvfO8shuf57BaghqFfPlYxofvL8/KUEfYiJOMMV+rV" crossorigin="anonymous">
    </script>

</body>

</html>